
export default {
  basePath: '/',
  entryPoints: new Map([['', () => import('./main.server.mjs')]]),
};
  